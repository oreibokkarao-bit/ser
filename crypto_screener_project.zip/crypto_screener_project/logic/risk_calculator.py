# logic/risk_calculator.py
import pandas as pd
import numpy as np
import logging
from typing import Dict, Any, List
from services.liq_manager import LiquidationWSManager # Import from services

class TP_SL_Calculator:
    def __init__(self, cfg: Dict[str, Any], liq_ws: LiquidationWSManager):
        self.cfg = cfg
        self.liq_ws = liq_ws

    def calculate(self, df: pd.DataFrame, symbol_ccxt: str) -> Dict[str, float]:
        last_price = float(df["close"].iloc[-1])
        
        try:
            # 1. Get Volatility (ATR)
            atr_levels = self._calculate_atr_based(df, last_price)
            sl_atr = atr_levels['sl']

            # 2. Get Liquidation Levels (for SL only)
            nodes = self.liq_ws.get_liquidation_nodes(symbol_ccxt, last_price)
            sl_support = sorted([p for p, v in nodes if p < last_price], reverse=True)

            # --- Set Dynamic Hybrid SL ---
            final_sl = sl_atr # Default to ATR stop
            if sl_support:
                sl_cluster_level = sl_support[0]
                sl_cluster_buffered = sl_cluster_level * 0.999 # Buffer
                final_sl = min(sl_atr, sl_cluster_buffered)

            # --- 3. Calculate Chandelier Exit (Trailing Stop) ---
            chandelier_period = self.cfg["atr_config"]["chandelier_period"]
            chandelier_mult = self.cfg["atr_config"]["chandelier_multiplier"]
            actual_period = min(chandelier_period, len(df))
            highest_high = float(df['high'].iloc[-actual_period:].max())
            current_atr = float(df['atr'].iloc[-1])
            initial_trail_stop = highest_high - (current_atr * chandelier_mult)
            initial_trail_stop = min(initial_trail_stop, last_price * 0.99)

            return self._format_results(last_price, final_sl, initial_trail_stop)

        except Exception as e:
            logging.error(f"Failed dynamic calculation for {symbol_ccxt}: {e}. Falling back to ATR.")
            fallback_levels = self._calculate_atr_based(df, last_price)
            return self._format_results(last_price, fallback_levels['sl'], fallback_levels['initial_trail_stop'])

    def _calculate_atr_based(self, df: pd.DataFrame, last_price: float) -> Dict[str, float]:
        atr = float(df["atr"].iloc[-1])
        sl_mult = float(self.cfg["atr_config"]["sl_multiplier"])
        sl = last_price - (atr * sl_mult)
        
        chandelier_period = self.cfg["atr_config"]["chandelier_period"]
        chandelier_mult = self.cfg["atr_config"]["chandelier_multiplier"]
        actual_period = min(chandelier_period, len(df))
        highest_high = float(df['high'].iloc[-actual_period:].max())
        initial_trail_stop = highest_high - (atr * chandelier_mult)
        initial_trail_stop = min(initial_trail_stop, last_price * 0.99)

        return {"sl": sl, "initial_trail_stop": initial_trail_stop}

    def _format_results(self, entry: float, sl: float, initial_trail_stop: float) -> Dict[str, float]:
        sl = min(entry * 0.999, sl) 
        return {
            "entry": round(entry, 6),
            "sl": round(sl, 6),
            "trail_stop_init": round(initial_trail_stop, 6),
        }
