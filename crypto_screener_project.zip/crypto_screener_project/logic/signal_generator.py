# logic/signal_generator.py
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
import logging

class SignalGenerator:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg

    def engineer_features(self, 
                          df_ohlcv: pd.DataFrame, 
                          cvd_series: pd.Series, 
                          oi_series: pd.Series,
                          current_funding_rate: float,
                          symbol_key: str) -> pd.DataFrame:
        """
        Engineers features from all data sources.
        """
        df = df_ohlcv.copy()
        z_window = self.cfg["z_score_window"]

        # --- 1. Standard OHLCV Features ---
        bb_len = self.cfg["ignition_filter"]["bollinger_len"]
        bb_std = self.cfg["ignition_filter"]["bollinger_std"]
        df['bb_ma'] = df['close'].rolling(window=bb_len).mean()
        df['bb_std'] = df['close'].rolling(window=bb_len).std()
        df['bb_upper'] = df['bb_ma'] + (df['bb_std'] * bb_std)
        df['bb_lower'] = df['bb_ma'] - (df['bb_std'] * bb_std)
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_ma']

        df['z_score_price'] = (df['close'] - df['close'].rolling(window=z_window).mean()) / df['close'].rolling(window=z_window).std()
        df['z_score_volume'] = (df['volume'] - df['volume'].rolling(window=z_window).mean()) / df['volume'].rolling(window=z_window).std()

        atr_period = self.cfg["atr_config"]["period"]
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = np.max(ranges, axis=1)
        df['atr'] = true_range.rolling(window=atr_period).mean()

        swing_lookback = self.cfg["swing_config"]["lookback"]
        df['swing_high'] = df['high'].rolling(window=swing_lookback, center=True).max()
        df['swing_low'] = df['low'].rolling(window=swing_lookback, center=True).min()
        
        df['symbol_key'] = symbol_key # Add for logging

        # --- 2. CVD Features ---
        if not cvd_series.empty:
            cvd_delta = cvd_series.diff()
            df['z_score_cvd'] = (cvd_delta - cvd_delta.rolling(window=z_window).mean()) / cvd_delta.rolling(window=z_window).std()
        else:
            df['z_score_cvd'] = 0.0

        # --- 3. Microstructure Features ---
        if not oi_series.empty:
            oi_pct_change = oi_series.pct_change()
            df['z_score_oi'] = (oi_pct_change - oi_pct_change.rolling(window=z_window).mean()) / oi_pct_change.rolling(window=z_window).std()
        else:
            df['z_score_oi'] = 0.0
            
        df['funding_rate'] = np.nan
        if not df.empty:
            df.iloc[-1, df.columns.get_loc('funding_rate')] = current_funding_rate

        return df.dropna(subset=['bb_upper', 'z_score_price', 'z_score_volume', 'atr'])

    def apply_ignition_filter(self, df: pd.DataFrame) -> bool:
        if df.empty: return False
        last = df.iloc[-1]
        
        # --- NEW: Macro Filter Check ---
        if self.cfg.get("MACRO_FILTERS_ENABLED", False):
            mvrv_z = self.cfg.get("BITCOIN_MVRV_Z", 0.0)
            nupl = self.cfg.get("BITCOIN_NUPL", 0.0)
            
            mvrv_max = self.cfg.get("MACRO_MVRV_Z_MAX", 7.0)
            nupl_max = self.cfg.get("MACRO_NUPL_MAX", 0.75)
            
            if mvrv_z > mvrv_max or nupl > nupl_max:
                # Uncomment to see which coins are being filtered
                # logging.info(f"Skipping {last['symbol_key']} due to Macro Filter: MVRV={mvrv_z}, NUPL={nupl}")
                return False

        # --- THE 6-POINT CONFLUENCE CHECK ---
        funding_rate = last.get('funding_rate', 0.0)
        
        return (
            last['bb_width'] < 0.06 and
            last['z_score_price'] > 0 and
            last['z_score_volume'] > 0 and
            last.get('z_score_cvd', 0) > 0.5 and
            last.get('z_score_oi', 0) > 0.5 and
            funding_rate < 0.00075
        )

    def generate_score(self, df: pd.DataFrame) -> float:
        if df.empty: return 0.0
        
        last = df.iloc[-1]
        zp = last.get("z_score_price", 0.0)
        zv = last.get("z_score_volume", 0.0)
        zc = last.get("z_score_cvd", 0.0)
        zo = last.get("z_score_oi", 0.0)
        
        zp = 0.0 if pd.isna(zp) else float(zp)
        zv = 0.0 if pd.isna(zv) else float(zv)
        zc = 0.0 if pd.isna(zc) else float(zc)
        zo = 0.0 if pd.isna(zo) else float(zo)
        
        return zp + zv + (zc * 1.5) + zo
