# config.py
"""
This file holds the central configuration for the entire screener.
"""

CONFIG = {
    "exchange": "binance",
    "market_type": "swap",
    "quote_currency": "USDT",
    "blacklist": ["USDC/USDT", "BUSD/USDT", "TUSD/USDT"],
    "timeframe": "15m",
    "lookback_period": 150,

    "z_score_window": 21,
    "ignition_filter": {"bollinger_len": 20, "bollinger_std": 2.0},

    "tp_sl_strategy": "atr", # Options: "atr", "swing", "liquidation"

    "atr_config": {
        "period": 14,
        "sl_multiplier": 2.0,
        "tp_multiplier": 4.0, # (This is now just a fallback)
        
        # --- CHANDELIER EXIT (Trailing Stop) ---
        "chandelier_period": 22,    # (Lookback for the "highest high")
        "chandelier_multiplier": 3.0  # (ATR multiplier for the trail)
    },
    
    "swing_config": {
        "lookback": 50
    },

    "scan_interval_seconds": 60,

    "liq_window_sec": 60 * 30,
    "liq_price_range_pct": 0.08,
    "liq_bin_step_pct": 0.0025,
    "liq_top_nodes": 4,
    "exchanges_liq": ["binance"],
    
    # --- ON-CHAIN MACRO FILTERS ---
    # (Manually update these daily from a free charting site)
    "MACRO_FILTERS_ENABLED": True,
    "BITCOIN_MVRV_Z": 2.1,   # Example value, update this
    "BITCOIN_NUPL": 0.55,    # Example value, update this
    
    # --- FILTERS FOR THE NEW MACRO RULES ---
    "MACRO_MVRV_Z_MAX": 6.0,  # (Rule: Don't long if MVRV-Z is above this "overvalued" level)
    "MACRO_NUPL_MAX": 0.7,    # (Rule: Don't long if NUPL is in "Euphoria")
}
