# services/microstructure_monitor.py
import asyncio
import logging
import ccxt.async_support as ccxt
from typing import List, Dict, Any
from services.signal_processor import SignalProcessor # This imports from a file in the same folder

class MicrostructureMonitor:
    """
    Polls the exchange's REST API to fetch futures-specific data like
    Open Interest and Funding Rates.
    """
    def __init__(self, 
                 exchange: ccxt.Exchange, 
                 symbols: List[str], 
                 signal_processor: 'SignalProcessor', 
                 poll_interval_sec: int = 300):
        
        self.exchange = exchange
        self.symbols = symbols
        self.signal_processor = signal_processor
        self.poll_interval_sec = poll_interval_sec
        
        self.symbol_id_map = {s: m['id'] for s, m in self.exchange.markets.items() if s in self.symbols}
        
        logging.info(f"MicrostructureMonitor initialized for {len(self.symbols)} symbols.")

    async def run_monitor(self):
        logging.info("Microstructure monitor task started...")
        while True:
            try:
                logging.info("MicrostructureMonitor: Fetching OI and Funding data...")
                tasks = [self.fetch_symbol_data(symbol) for symbol in self.symbols]
                await asyncio.gather(*tasks)
                logging.info("MicrostructureMonitor: Data fetch complete.")
                
            except Exception as e:
                logging.error(f"Error in MicrostructureMonitor loop: {e}")
            
            await asyncio.sleep(self.poll_interval_sec)

    async def fetch_symbol_data(self, symbol: str):
        symbol_key = self.signal_processor._symbol_to_key(symbol)
        
        try:
            # --- Fetch Open Interest ---
            symbol_id = self.symbol_id_map.get(symbol)
            if not symbol_id:
                logging.warning(f"No market ID found for {symbol}, skipping OI fetch.")
                return

            oi_data = await self.exchange.fetch_open_interest(symbol_id)
            oi_value = float(oi_data.get('openInterestAmount', 0.0))
            
            # --- Fetch Funding Rate ---
            funding_data = await self.exchange.fetch_funding_rate(symbol)
            funding_rate = float(funding_data.get('fundingRate', 0.0))

            # --- Write data to the central store ---
            store = self.signal_processor.market_data_store[symbol_key]
            store["open_interest"] = oi_value
            store["funding_rate"] = funding_rate
            
        except ccxt.NetworkError as e:
            logging.warning(f"Microstructure fetch (NetworkError) for {symbol}: {e}")
        except ccxt.ExchangeError as e:
            logging.warning(f"Microstructure fetch (ExchangeError) for {symbol}: {e}")
        except Exception as e:
            logging.error(f"Failed to fetch microstructure data for {symbol}: {e}")
