# services/liq_manager.py
import asyncio
import json
import logging
import math
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Dict, List, Tuple, Any, Optional
import numpy as np
import websockets

@dataclass
class LiqNode:
    price: float
    density: float

class LiquidationWSManager:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self._data = defaultdict(lambda: defaultdict(lambda: deque(maxlen=1000)))
        self._lock = threading.Lock()
        self._thread = threading.Thread(target=self._run_forever, daemon=True)

    def start(self):
        self._thread.start()
        logging.info("LiquidationWSManager thread started.")

    def _run_forever(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self._connect_all())
        loop.run_forever()

    async def _connect_all(self):
        tasks = [self._listen(exchange) for exchange in self.cfg["exchanges_liq"]]
        await asyncio.gather(*tasks)

    async def _listen(self, exchange_name: str):
        urls = {
            'binance': 'wss://fstream.binance.com/ws/!forceOrder@arr',
        }
        url = urls.get(exchange_name.lower())
        if not url: return

        while True:
            try:
                async with websockets.connect(url) as ws:
                    logging.info(f"Connected to {exchange_name} liquidation stream.")
                    while True:
                        msg = await ws.recv()
                        data = json.loads(msg)
                        self._process_message(exchange_name, data)
            except Exception as e:
                logging.error(f"Liquidation WS error ({exchange_name}): {e}. Reconnecting...")
                await asyncio.sleep(5)

    def _process_message(self, exchange: str, data: Dict):
        try:
            if exchange == 'binance':
                order = data.get('o', {})
                symbol = order.get('s')
                if not symbol or not symbol.endswith('USDT'): return
                price = float(order.get('p'))
                qty = float(order.get('q'))
                side = order.get('S')
                timestamp = int(order.get('T')) 

                with self._lock:
                    self._data[exchange][symbol].append((timestamp, price, qty, side))
        except (KeyError, ValueError, TypeError) as e:
            timestamp_val = order.get('T') if 'order' in locals() else 'N/A'
            logging.warning(f"Error processing liq message: {e} | T={timestamp_val} | Data: {data}")

    def get_liquidation_nodes(self, symbol_ccxt: str, current_price: float) -> List[Tuple[float, float]]:
        try:
            WINDOW_SEC = self.cfg["liq_window_sec"]
            PRICE_RANGE_PCT = self.cfg["liq_price_range_pct"]
            BIN_STEP_PCT = self.cfg["liq_bin_step_pct"]
            TOP_NODES = self.cfg["liq_top_nodes"]
        except KeyError as e:
            logging.error(f"Liquidation config missing key: {e}")
            return []

        min_price = current_price * (1.0 - PRICE_RANGE_PCT)
        max_price = current_price * (1.0 + PRICE_RANGE_PCT)
        bin_size = current_price * BIN_STEP_PCT
        if bin_size == 0:
            return []
            
        symbol_key = symbol_ccxt.replace('/', '')
        with self._lock:
            raw_data = list(self._data.get('binance', {}).get(symbol_key, []))

        if not raw_data: return []

        now_ms = int(time.time() * 1000)
        min_time_ms = now_ms - (WINDOW_SEC * 1000)
        
        filtered_data = [
            (price, qty) for (ts, price, qty, side) in raw_data
            if ts >= min_time_ms and min_price <= price <= max_price
        ]

        if not filtered_data: return []

        prices = [p for p, q in filtered_data]
        data_min_price = min(prices)
        data_max_price = max(prices)

        num_bins = int((data_max_price - data_min_price) / bin_size) + 1
        if num_bins <= 0 or num_bins > 2000:
            return []

        hist, bin_edges = np.histogram(
            a=[p for p, q in filtered_data],
            bins=num_bins,
            range=(data_min_price, data_max_price),
            weights=[q for p, q in filtered_data]
        )

        top_indices = np.argsort(hist)[-TOP_NODES:]
        
        nodes = []
        for i in top_indices:
            if hist[i] > 0:
                bin_center_price = (bin_edges[i] + bin_edges[i+1]) / 2.0
                nodes.append((bin_center_price, hist[i]))

        return sorted(nodes, key=lambda x: x[0])
