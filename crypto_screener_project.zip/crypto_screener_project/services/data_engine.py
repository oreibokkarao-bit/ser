# services/data_engine.py
import asyncio
import json
import logging
import websockets
import ccxt.async_support as ccxt
import pandas as pd
from typing import Dict, List, Any, Optional

class DataEngine:
    """
    Manages real-time WebSocket data streams for multiple exchanges.
    """
    def __init__(self, symbols_map: Dict[str, List[str]]):
        self.symbols_map = symbols_map
        self.agg_trade_queue = asyncio.Queue()
        self.l2_book_queue = asyncio.Queue() # (Currently unused, but ready)
        logging.info("DataEngine initialized for real-time streaming.")

    async def start_producers(self):
        tasks = []
        if "binance" in self.symbols_map:
            logging.info(f"Starting Binance producers for {len(self.symbols_map['binance'])} symbols...")
            tasks.append(self._binance_aggtrade_producer(self.symbols_map['binance']))
            # Add L2 book producer task here if needed
            
        if not tasks:
            logging.warning("DataEngine: No producers to start. Check symbols map.")
            return
        await asyncio.gather(*tasks)

    async def _binance_aggtrade_producer(self, symbols: List[str]):
        stream_names = [f"{s.replace('/', '').lower()}@aggTrade" for s in symbols]
        chunk_size = 50 
        chunks = [stream_names[i:i + chunk_size] for i in range(0, len(stream_names), chunk_size)]
        url_base = "wss://fstream.binance.com/stream?streams="
        
        connect_tasks = []
        for i, chunk in enumerate(chunks):
            stream_path = "/".join(chunk)
            url = f"{url_base}{stream_path}"
            producer_name = f"BinanceAggTrade-Chunk-{i+1}"
            connect_tasks.append(self._ws_connect_loop(url, producer_name, self.agg_trade_queue))
            
        await asyncio.gather(*connect_tasks)

    async def _ws_connect_loop(self, url: str, producer_name: str, queue: asyncio.Queue):
        while True:
            try:
                async with websockets.connect(url) as ws:
                    logging.info(f"Producer '{producer_name}' connected.")
                    while True:
                        msg = await ws.recv()
                        data = json.loads(msg)
                        await queue.put(data)
                        
            except websockets.exceptions.ConnectionClosed as e:
                logging.warning(f"Producer '{producer_name}' disconnected: {e}. Reconnecting in 5s...")
            except Exception as e:
                logging.error(f"Producer '{producer_name}' error: {e}. Reconnecting in 5s...")
            
            await asyncio.sleep(5)
