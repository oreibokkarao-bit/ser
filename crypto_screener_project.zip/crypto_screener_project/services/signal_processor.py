# services/signal_processor.py
import pandas as pd
from collections import defaultdict
import logging
from typing import Dict, Any, List
from services.data_engine import DataEngine # Import from same folder

class SignalProcessor:
    """
    Consumes real-time data from DataEngine queues.
    Calculates signals like CVD and builds in-memory OHLCV bars.
    """
    def __init__(self, data_engine: DataEngine, symbols: List[str]):
        self.data_engine = data_engine
        
        self.market_data_store = defaultdict(lambda: {
            "cvd": 0.0,
            "cvd_series": pd.Series(dtype=float),
            "ohlcv_1m": None, 
            "ohlcv_15m": None,
            "open_interest": 0.0,
            "funding_rate": 0.0,
            "oi_series": pd.Series(dtype=float)
        })
        
        self._temp_bars = {}
        for symbol in symbols:
            key = self._symbol_to_key(symbol)
            self._temp_bars[key] = {
                "timestamp": None, "open": None, "high": -float('inf'), 
                "low": float('inf'), "close": None, "volume": 0.0
            }

        logging.info(f"SignalProcessor initialized for {len(symbols)} symbols.")

    def _symbol_to_key(self, ccxt_symbol: str) -> str:
        return ccxt_symbol.replace('/', '')

    def _key_to_symbol(self, key: str) -> str:
        if key.endswith("USDT"):
            return f"{key[:-4]}/{key[-4:]}"
        return key # Fallback

    async def run_consumer(self):
        logging.info("SignalProcessor consumer task started...")
        while True:
            try:
                msg = await self.data_engine.agg_trade_queue.get()
                stream_name = msg.get("stream")
                trade_data = msg.get("data")

                if not stream_name or not trade_data: continue
                
                symbol_key = stream_name.split('@')[0].upper() 
                
                self.process_cvd(symbol_key, trade_data)
                self.process_ohlcv_builder(symbol_key, trade_data)

            except Exception as e:
                logging.error(f"Error in SignalProcessor consumer: {e}")

    def process_cvd(self, symbol_key: str, trade_data: Dict[str, Any]):
        try:
            qty = float(trade_data['q'])
            is_buyer_maker = trade_data['m']
            trade_volume = -qty if is_buyer_maker else qty
            self.market_data_store[symbol_key]["cvd"] += trade_volume
        except (KeyError, ValueError) as e:
            logging.warning(f"Error processing CVD for {symbol_key}: {e}")

    def process_ohlcv_builder(self, symbol_key: str, trade_data: Dict[str, Any]):
        try:
            price = float(trade_data['p'])
            qty = float(trade_data['q'])
            timestamp_ms = int(trade_data['T'])
            minute_timestamp = (timestamp_ms // 60000) * 60000 
            
            bar = self._temp_bars.get(symbol_key)
            if not bar: return # Skip if symbol not initialized

            if bar["timestamp"] != minute_timestamp:
                if bar["timestamp"] is not None:
                    closed_bar_data = {
                        "timestamp": pd.to_datetime(bar["timestamp"], unit='ms'),
                        "open": bar["open"],
                        "high": bar["high"],
                        "low": bar["low"],
                        "close": bar["close"],
                        "volume": bar["volume"]
                    }
                    new_row = pd.DataFrame([closed_bar_data]).set_index("timestamp")
                    
                    current_df = self.market_data_store[symbol_key]["ohlcv_1m"]
                    if current_df is None:
                        self.market_data_store[symbol_key]["ohlcv_1m"] = new_row
                    else:
                        self.market_data_store[symbol_key]["ohlcv_1m"] = pd.concat([current_df, new_row])
                    
                    self.resample_to_15m(symbol_key)

                bar["timestamp"] = minute_timestamp
                bar["open"] = price
                bar["high"] = price
                bar["low"] = price
                bar["close"] = price
                bar["volume"] = qty
            else:
                bar["high"] = max(bar["high"], price)
                bar["low"] = min(bar["low"], price)
                bar["close"] = price
                bar["volume"] += qty
        except (KeyError, ValueError) as e:
            logging.warning(f"Error processing OHLCV for {symbol_key}: {e}")

    def resample_to_15m(self, symbol_key: str):
        df_1m = self.market_data_store[symbol_key]["ohlcv_1m"]
        if df_1m is None or df_1m.empty:
            return

        self.market_data_store[symbol_key]["ohlcv_1m"] = df_1m.iloc[-3000:]

        try:
            df_15m = df_1m['open'].resample('15T').first().to_frame()
            df_15m['high'] = df_1m['high'].resample('15T').max()
            df_15m['low'] = df_1m['low'].resample('15T').min()
            df_15m['close'] = df_1m['close'].resample('15T').last()
            df_15m['volume'] = df_1m['volume'].resample('15T').sum()
            df_15m = df_15m.dropna()
            
            self.market_data_store[symbol_key]["ohlcv_15m"] = df_15m

            # --- Align CVD and OI data to new 15m candle ---
            last_timestamp = df_15m.index[-1]
            
            current_cvd = self.market_data_store[symbol_key]["cvd"]
            self.market_data_store[symbol_key]["cvd_series"].at[last_timestamp] = current_cvd
            self.market_data_store[symbol_key]["cvd_series"] = \
                self.market_data_store[symbol_key]["cvd_series"].iloc[-300:]

            current_oi = self.market_data_store[symbol_key]["open_interest"]
            if current_oi > 0:
                self.market_data_store[symbol_key]["oi_series"].at[last_timestamp] = current_oi
                self.market_data_store[symbol_key]["oi_series"] = \
                    self.market_data_store[symbol_key]["oi_series"].iloc[-300:]

        except Exception as e:
            logging.error(f"Failed to resample {symbol_key} to 15m: {e}")
