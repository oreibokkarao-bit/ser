# run_screener.py
"""
This is the main entry point for the screener.
It imports all services and logic, starts them,
and runs the main scan_loop.
"""
import asyncio
import ccxt.async_support as ccxt
import logging
import math
import pandas as pd
import numpy as np
from tabulate import tabulate
from typing import List, Dict, Any

# --- Local Imports ---
from config import CONFIG
from services.data_engine import DataEngine
from services.liq_manager import LiquidationWSManager
from services.microstructure_monitor import MicrostructureMonitor
from services.signal_processor import SignalProcessor
from logic.signal_generator import SignalGenerator
from logic.risk_calculator import TP_SL_Calculator

# --- Basic Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


async def scan_loop(exchange: ccxt.Exchange, 
                    signal_processor: SignalProcessor, 
                    liq_ws_manager: LiquidationWSManager):
    """
    This is the main scanning loop that finds and prints trade opportunities.
    """
    signal_gen = SignalGenerator(CONFIG)
    tp_sl_calculator = TP_SL_Calculator(CONFIG, liq_ws_manager)
    
    # Give the processor and monitor a moment to fill some data
    logging.info("Allowing 15 seconds for initial data population...")
    await asyncio.sleep(15) 
    
    while True:
        logging.info("--- Starting new scan cycle ---")
        potential_trades = []
        
        # This loop now scans the in-memory store
        for symbol_key, data in signal_processor.market_data_store.items():
            
            df_15m = data["ohlcv_15m"]
            cvd_series = data["cvd_series"]
            oi_series = data["oi_series"]
            funding_rate = data["funding_rate"]
            
            # Check if we have enough data to scan
            if df_15m is None or len(df_15m) < CONFIG['lookback_period']:
                continue # Not enough data yet

            # --- PASS ALL DATA TO THE GENERATOR ---
            df_feat = signal_gen.engineer_features(
                df_15m, 
                cvd_series, 
                oi_series, 
                funding_rate,
                symbol_key # Pass symbol_key for logging
            )
            
            if signal_gen.apply_ignition_filter(df_feat):
                score = signal_gen.generate_score(df_feat)
                ccxt_symbol = signal_processor._key_to_symbol(symbol_key)
                
                potential_trades.append({
                    "symbol": ccxt_symbol, 
                    "score": score, 
                    "dataframe": df_feat
                })

        # --- Tabulate and Print Results ---
        if not potential_trades:
            logging.info("Scan complete. No assets passed the Ignition Filter.")
        else:
            top_candidates = sorted(potential_trades, key=lambda x: x["score"], reverse=True)[:5]
            logging.info(f"Scan complete. Top {len(top_candidates)} candidates:")
            
            headers = ["🪙 SYMBOL", "📊 SCORE", "💡 CONF.", "📈 RR", "💰 EXP.", "🛑 SL", "🏃 TRAIL STOP"]
            table_data = []

            for i, c in enumerate(top_candidates, start=1):
                trade_params = tp_sl_calculator.calculate(c["dataframe"], c["symbol"])

                entry = trade_params["entry"]
                sl = trade_params["sl"]
                trail_stop = trade_params["trail_stop_init"]
                score = c["score"]

                risk = entry - sl
                # A rough proxy for RR
                reward_potential = (entry - trail_stop) + risk 
                
                if risk <= 0:
                    logging.warning(f"Skipping {c['symbol']} due to invalid risk (risk <= 0). Entry: {entry}, SL: {sl}")
                    continue 

                risk_reward_ratio = reward_potential / risk
                confidence = 1 / (1 + math.exp(-0.5 * score)) # Sigmoid
                expectancy = (confidence * reward_potential) - ((1 - confidence) * risk)

                table_data.append([
                    c["symbol"], 
                    round(score, 2),
                    f"{confidence:.1%}",
                    round(risk_reward_ratio, 1),
                    round(expectancy, 2),
                    f"{trade_params['sl']:.6g}",
                    f"{trade_params['trail_stop_init']:.6g}",
                ])

            print("\nTop 5 Ignition Candidates")
            print(tabulate(table_data, headers=headers, tablefmt="grid"))

        logging.info(f"--- Scan cycle finished. Waiting {CONFIG['scan_interval_seconds']} seconds. ---")
        await asyncio.sleep(CONFIG['scan_interval_seconds'])


async def main():
    exchange = ccxt.binance({
        'asyncio_loop': asyncio.get_event_loop(),
        'options': {'defaultType': CONFIG['market_type']}
    })

    # --- 1. Load Markets (Moved to top) ---
    logging.info("Fetching market data...")
    try:
        await exchange.load_markets()
    except Exception as e:
        logging.error(f"Failed to load markets: {e}")
        await exchange.close()
        return
        
    symbols = [m['symbol'] for m in exchange.markets.values()
               if m.get('type') == 'swap'
               and m['quote'] == CONFIG['quote_currency']
               and m['symbol'] not in CONFIG['blacklist']
               and m['active']]
    logging.info(f"Found {len(symbols)} symbols to scan.")
    
    symbols_map = {"binance": symbols}
    
    # --- 2. Start Services ---
    data_engine = DataEngine(symbols_map)
    liq_ws_manager = LiquidationWSManager(CONFIG)
    liq_ws_manager.start() # Runs in a separate thread

    signal_processor = SignalProcessor(data_engine, symbols)

    monitor = MicrostructureMonitor(exchange, symbols, signal_processor, poll_interval_sec=300)

    # --- 3. Run All Async Tasks ---
    try:
        producer_task = asyncio.create_task(data_engine.start_producers())
        consumer_task = asyncio.create_task(signal_processor.run_consumer())
        scanner_task = asyncio.create_task(scan_loop(exchange, signal_processor, liq_ws_manager))
        monitor_task = asyncio.create_task(monitor.run_monitor())
        
        await asyncio.gather(producer_task, consumer_task, scanner_task, monitor_task)
        
    except KeyboardInterrupt:
        logging.info("Script terminated by user.")
    except Exception as e:
        logging.error(f"Main loop encountered critical error: {e}")
    finally:
        await exchange.close()
        logging.info("Exchange connection closed. Exiting.")


if __name__ == "__main__":
    asyncio.run(main())
