# ##############################################################################
# ## Robust 4-Hour Pump Bot (v3.5 - New Ignition Trigger) ##
# ## Replaced VWAP Reclaim with multi-factor "Ignition" logic. ##
# ##############################################################################

import asyncio
import argparse
import sys
import time
import logging
import hashlib
import aiosqlite
import hmac
import configparser
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Any, Tuple

import aiohttp
import numpy as np
import pandas as pd
import pandas_ta as ta  # <--- NEW: Import pandas-ta
import rfc8785
from tabulate import tabulate
from tenacity import retry, stop_after_attempt, wait_random_exponential, retry_if_exception_type

# --- ANSI Color Codes for terminal output ---
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'

# --- CONFIGURATION (Defaults) ---
DB_FILE = "data/4h_pump_ledger.db"
LOG_FILE = "logs/bot.log"
REPLAY_WINDOW_HOURS = 6
RECENCY_HALF_LIFE_MIN = 45
SCAN_INTERVAL_SECONDS = 300 # 5 minutes
L1_LOOKBACK_DAYS = 5
L1_MIN_SPOT_ACCUMULATION_PCT = 15.0
L2_MOMENTUM_IGNITION_LOOKBACK = 30 # 5m candles
L2_MIN_MOMENTUM_IGNITION_SCORE = 10.0
L3_MAX_FUT_SPOT_VOL_RATIO = 4.0
MIN_24H_NOTIONAL_VOLUME = 10_000_000
MAX_BID_ASK_SPREAD_PCT = 0.1

# --- NEW: Ignition Trigger Config ---
# We use 15m timeframe for the trigger check
TRIGGER_TIMEFRAME = '15m' 
TRIGGER_ADX_MIN = 25
TRIGGER_VOL_MULT = 3.0
TRIGGER_RSI_MIN = 50

API_CONFIG = {
    'binance': {
        'fapi': 'https://fapi.binance.com', 'api': 'https://api.binance.com',
        'rate_limit': (2000, 60), # weight/min
        'tf_map': {'1m': '1m', '5m': '5m', '15m': '15m', '1d': '1d', '4h': '4h'} # Added 15m
    }
}

# --- LOGGING & CONSOLE SETUP ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)

# --- UTILITY CLASSES ---
# ... (AsyncTokenBucket and DBManager are unchanged) ...
class AsyncTokenBucket:
    def __init__(self, rate: float, capacity: int):
        self.rate, self.capacity, self._tokens, self.last_refill = rate, capacity, float(capacity), time.monotonic()
        self.lock = asyncio.Lock()
    async def acquire(self, tokens: int = 1):
        async with self.lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            if elapsed > 0:
                self._tokens = min(self.capacity, self._tokens + (elapsed * self.rate))
                self.last_refill = now
            while self._tokens < tokens:
                await asyncio.sleep(0.1)
                await self.acquire(tokens=0) # Re-check after waking up
            self._tokens -= tokens

class DBManager:
    @staticmethod
    async def initialize():
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("PRAGMA journal_mode=WAL;")
            await db.execute("""
                CREATE TABLE IF NOT EXISTS signal_ledger (
                    event_id TEXT PRIMARY KEY, symbol TEXT NOT NULL, exchange TEXT NOT NULL,
                    event_time INTEGER NOT NULL, l1_score REAL, l2_score REAL, status TEXT,
                    metrics TEXT
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS active_trades (
                    trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    status TEXT NOT NULL, 
                    entry_price REAL,
                    stop_loss_price REAL,
                    take_profit_price REAL,
                    position_size REAL,
                    entry_time INTEGER,
                    exit_time INTEGER,
                    exit_reason TEXT,
                    tp_order_id TEXT, 
                    sl_order_id TEXT, 
                    FOREIGN KEY (event_id) REFERENCES signal_ledger (event_id)
                )
            """)
            await db.commit()

    @staticmethod
    async def write_event(event_id, symbol, exchange, event_time, l1_score, l2_score, metrics):
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute(
                "INSERT OR IGNORE INTO signal_ledger VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (event_id, symbol, exchange, int(event_time.timestamp()), l1_score, l2_score, 'DETECTED', str(metrics))
            )
            await db.commit()

    @staticmethod
    async def update_status(event_id, status):
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("UPDATE signal_ledger SET status = ? WHERE event_id = ?", (status, event_id))
            await db.commit()

    @staticmethod
    async def query_recent_events():
        cutoff = int((datetime.now(timezone.utc) - timedelta(hours=REPLAY_WINDOW_HOURS)).timestamp())
        async with aiosqlite.connect(DB_FILE) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT * FROM signal_ledger WHERE event_time >= ? ORDER BY event_time DESC", (cutoff,))
            return await cursor.fetchall()

    @staticmethod
    async def open_new_trade(event_id, symbol, entry_price, sl_price, tp_price, position_size, tp_order_id, sl_order_id):
        entry_time = int(datetime.now(timezone.utc).timestamp())
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute(
                """INSERT INTO active_trades 
                   (event_id, symbol, status, entry_price, stop_loss_price, take_profit_price, position_size, entry_time, tp_order_id, sl_order_id) 
                   VALUES (?, ?, 'LIVE', ?, ?, ?, ?, ?, ?, ?)""",
                (event_id, symbol, entry_price, sl_price, tp_price, position_size, entry_time, tp_order_id, sl_order_id)
            )
            await db.commit()

    @staticmethod
    async def close_trade(trade_id, exit_reason):
        exit_time = int(datetime.now(timezone.utc).timestamp())
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute(
                "UPDATE active_trades SET status = 'CLOSED', exit_time = ?, exit_reason = ? WHERE trade_id = ?",
                (exit_time, exit_reason, trade_id)
            )
            await db.commit()
            
    @staticmethod
    async def get_live_trades():
        async with aiosqlite.connect(DB_FILE) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT * FROM active_trades")
            return await cursor.fetchall()


# --- EXCHANGE MANAGER & DATA FETCHING ---
class BinanceManager:
    def __init__(self, session: aiohttp.ClientSession, api_key: str, api_secret: str):
        self.name = 'binance'
        self.session = session
        self.config = API_CONFIG[self.name]
        self.api_key = api_key
        self.api_secret = api_secret
        rate, period = self.config['rate_limit']
        self.limiter = AsyncTokenBucket(rate / period, rate)

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, max=10), retry=retry_if_exception_type(aiohttp.ClientError))
    async def _fetch(self, url: str, params: Optional[Dict] = None, weight: int = 1) -> Any:
        await self.limiter.acquire(weight)
        try:
            async with self.session.get(url, params=params, timeout=20) as response:
                if response.status in [429, 418]:
                    retry_after = int(response.headers.get('Retry-After', '60'))
                    logging.warning(f"[BINANCE] Rate limited. Halting requests for {retry_after}s.")
                    await asyncio.sleep(retry_after + 1)
                    response.raise_for_status()
                response.raise_for_status()
                return await response.json()
        except Exception as e:
            raise
    
    async def get_klines(self, symbol, interval, limit, is_f=True):
        base = self.config['fapi'] if is_f else self.config['api']
        endpoint = "/fapi/v1/klines" if is_f else "/api/v3/klines"
        weight = 2 if limit > 100 else 1
        tf = self.config['tf_map'].get(interval, interval)
        return await self._fetch(f"{base}{endpoint}", {'symbol': symbol, 'interval': tf, 'limit': limit}, weight)

    async def get_oi_history(self, symbol, period, limit):
         return await self._fetch(f"{self.config['fapi']}/futures/data/openInterestHist", {'symbol': symbol, 'period': period, 'limit': limit}, 1)
         
    async def get_all_tickers_24h(self, is_f=True):
        base = self.config['fapi'] if is_f else self.config['api']
        endpoint = "/fapi/v1/ticker/24hr" if is_f else "/api/v3/ticker/24hr"
        return await self._fetch(f"{base}{endpoint}", weight=40)

    async def get_all_book_tickers(self):
        return await self._fetch(f"{self.config['fapi']}/fapi/v1/ticker/bookTicker", weight=2)

    async def get_all_perp_info(self):
        return await self._fetch(f"{self.config['fapi']}/fapi/v1/exchangeInfo", weight=1)

    def _create_signature(self, params: Dict) -> str:
        query_string = "&".join(f"{k}={v}" for k, v in params.items())
        return hmac.new(self.api_secret.encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256).hexdigest()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, max=10), retry=retry_if_exception_type(aiohttp.ClientError))
    async def _post_signed_order(self, endpoint: str, params: Dict, weight: int = 1) -> Any:
        await self.limiter.acquire(weight)
        params['timestamp'] = int(time.time() * 1000)
        params['signature'] = self._create_signature(params)
        headers = {'X-MBX-APIKEY': self.api_key}
        url = f"{self.config['fapi']}{endpoint}"
        try:
            async with self.session.post(url, headers=headers, data=params, timeout=20) as response:
                if response.status >= 400:
                    logging.error(f"Binance order error {response.status}: {await response.text()}")
                    if response.status in [429, 418]:
                         retry_after = int(response.headers.get('Retry-After', '60'))
                         logging.warning(f"[BINANCE] Rate limited. Halting requests for {retry_after}s.")
                         await asyncio.sleep(retry_after + 1)
                    response.raise_for_status()
                return await response.json()
        except Exception as e:
            logging.error(f"Failed to post signed order: {e}")
            raise

    async def place_market_order(self, symbol: str, side: str, quantity: float) -> Optional[Dict]:
        params = {
            'symbol': symbol,
            'side': side,
            'type': 'MARKET',
            'quantity': f"{quantity:.3f}", 
        }
        try:
            return await self._post_signed_order("/fapi/v1/order", params, weight=1)
        except Exception as e:
            logging.error(f"Failed to place market order for {symbol}: {e}")
            return None

    async def place_oco_order(
        self, symbol: str, 
        quantity: float, 
        take_profit_price: float, 
        stop_loss_price: float
    ) -> Optional[Dict]:
        logging.info(f"Placing OCO (2 orders) for {symbol}: TP={take_profit_price}, SL={stop_loss_price}")
        try:
            tp_params = {
                'symbol': symbol,
                'side': 'SELL',
                'type': 'LIMIT',
                'quantity': f"{quantity:.3f}",
                'price': f"{take_profit_price:.2f}",
                'timeInForce': 'GTC',
                'reduceOnly': 'true'
            }
            tp_order = await self._post_signed_order("/fapi/v1/order", tp_params)
            
            sl_params = {
                'symbol': symbol,
                'side': 'SELL',
                'type': 'STOP_MARKET',
                'quantity': f"{quantity:.3f}",
                'stopPrice': f"{stop_loss_price:.2f}",
                'reduceOnly': 'true',
                'priceProtect': 'true'
            }
            sl_order = await self._post_signed_order("/fapi/v1/order", sl_params)

            if tp_order and sl_order:
                logging.info(f"Successfully placed TP (ID: {tp_order['orderId']}) and SL (ID: {sl_order['orderId']})")
                return {'tp_order': tp_order, 'sl_order': sl_order}
            else:
                raise Exception("One or both OCO orders failed to place.")
                
        except Exception as e:
            logging.error(f"CRITICAL: OCO Order placement failed for {symbol}: {e}.")
            return None
            
    async def check_order_status(self, symbol: str, order_id: str) -> Optional[Dict]:
        params = { 'symbol': symbol, 'orderId': order_id }
        await self.limiter.acquire(1)
        params['timestamp'] = int(time.time() * 1000)
        params['signature'] = self._create_signature(params)
        headers = {'X-MBX-APIKEY': self.api_key}
        url = f"{self.config['fapi']}/fapi/v1/order"
        try:
            async with self.session.get(url, headers=headers, params=params, timeout=20) as response:
                response.raise_for_status()
                return await response.json()
        except Exception as e:
            logging.error(f"Failed to check order status for {order_id}: {e}")
            return None

    async def cancel_order(self, symbol: str, order_id: str) -> Optional[Dict]:
        params = { 'symbol': symbol, 'orderId': order_id }
        await self.limiter.acquire(1)
        params['timestamp'] = int(time.time() * 1000)
        params['signature'] = self._create_signature(params)
        headers = {'X-MBX-APIKEY': self.api_key}
        url = f"{self.config['fapi']}/fapi/v1/order"
        try:
            async with self.session.delete(url, headers=headers, data=params, timeout=20) as response:
                response.raise_for_status()
                return await response.json()
        except Exception as e:
            logging.error(f"Failed to cancel order {order_id}: {e}")
            return None

# --- CORE LOGIC & REPLAY ENGINE ---
class StrategyEngine:
    def __init__(self, mgr: BinanceManager):
        self.mgr = mgr

    def _generate_event_id(self, symbol: str, event_time: pd.Timestamp) -> str:
        data = {"symbol": symbol, "timestamp": event_time.isoformat(), "strategy": "4h_pump_v3"}
        canonical_json = rfc8785.dumps(data)
        return hashlib.sha256(canonical_json).hexdigest()

    async def run_universe_curation(self, symbols: List[str]) -> List[str]:
        logging.info("Fetching bulk data for curation...")
        try:
            tickers_fut, tickers_spot, books = await asyncio.gather(
                self.mgr.get_all_tickers_24h(is_f=True),
                self.mgr.get_all_tickers_24h(is_f=False),
                self.mgr.get_all_book_tickers()
            )
        except Exception as e:
            logging.error(f"Failed to fetch bulk data for curation: {e}. Aborting cycle.")
            return []

        fut_tickers = {t['symbol']: t for t in tickers_fut}
        spot_tickers = {t['symbol']: t for t in tickers_spot}
        book_tickers = {b['symbol']: b for b in books}
        
        curated = []
        logging.info("Applying curation filters...")
        for symbol in symbols:
            fut_ticker = fut_tickers.get(symbol)
            spot_ticker = spot_tickers.get(symbol)
            book_ticker = book_tickers.get(symbol)

            if not all([fut_ticker, spot_ticker, book_ticker]):
                continue
            if float(fut_ticker['quoteVolume']) < MIN_24H_NOTIONAL_VOLUME:
                continue
            bid_price = float(book_ticker['bidPrice'])
            ask_price = float(book_ticker['askPrice'])
            if bid_price == 0: continue
            spread = (ask_price / bid_price - 1) * 100
            if spread > MAX_BID_ASK_SPREAD_PCT:
                continue
            curated.append(symbol)
        return curated

    async def process_symbol_replay(self, symbol: str):
        try:
            kl_spot_d, kl_spot_5m, oi_hist_5m, kl_perp_1m = await asyncio.gather(
                self.mgr.get_klines(symbol, '1d', L1_LOOKBACK_DAYS, is_f=False),
                self.mgr.get_klines(symbol, '5m', REPLAY_WINDOW_HOURS * 12 + L2_MOMENTUM_IGNITION_LOOKBACK, is_f=False),
                self.mgr.get_oi_history(symbol, '5m', REPLAY_WINDOW_HOURS * 12 + 2),
                self.mgr.get_klines(symbol, '1m', 1, is_f=True)
            )
            if not all([kl_spot_d, kl_spot_5m, oi_hist_5m, kl_perp_1m]): return
            
            spot_accum_pct = self._calculate_cvd_from_klines(kl_spot_d)
            if spot_accum_pct < L1_MIN_SPOT_ACCUMULATION_PCT: return

            df_spot_5m = pd.DataFrame(kl_spot_5m, columns=['ts', 'o', 'h', 'l', 'c', 'v', 'ct', 'qv', 'tr', 'tbav', 'tbqv', 'ig'])
            df_oi_5m = pd.DataFrame(oi_hist_5m)

            for i in range(L2_MOMENTUM_IGNITION_LOOKBACK, len(df_spot_5m)):
                event_time = pd.to_datetime(df_spot_5m.iloc[i]['ts'], unit='ms', utc=True)
                
                spot_slice = df_spot_5m.iloc[i-L2_MOMENTUM_IGNITION_LOOKBACK:i].values.tolist()
                oi_slice = df_oi_5m[pd.to_datetime(df_oi_5m['timestamp'], unit='ms', utc=True) <= event_time].tail(2).to_dict('records')
                ignition_score = self._calculate_momentum_ignition(spot_slice, oi_slice)

                if ignition_score and ignition_score >= L2_MIN_MOMENTUM_IGNITION_SCORE:
                    metrics = {"l1_cvd_pct": round(spot_accum_pct, 2), "l2_ign_score": round(ignition_score, 2)}
                    event_id = self._generate_event_id(symbol, event_time)
                    await DBManager.write_event(event_id, symbol, self.mgr.name, event_time, spot_accum_pct, ignition_score, metrics)
        except Exception as e:
            logging.debug(f"Error processing {symbol}: {e}")

    def _calculate_cvd_from_klines(self, kl: List) -> float:
        if not kl: return 0.0
        deltas = [(float(k[5]) if float(k[4]) > float(k[1]) else -float(k[5])) for k in kl]
        c_deltas = np.cumsum(deltas)
        return ((c_deltas[-1] / c_deltas[0]) - 1) * 100 if len(c_deltas) > 1 and c_deltas[0] != 0 else 0.0

    def _calculate_momentum_ignition(self, spot_klines_5m: List, oi_hist_5m: List) -> Optional[float]:
        if len(oi_hist_5m) < 2: return None
        spot_cvd_change_5m = self._calculate_cvd_from_klines(spot_klines_5m)
        oi_change_5m = ((float(oi_hist_5m[-1]['sumOpenInterest']) / float(oi_hist_5m[-2]['sumOpenInterest'])) - 1) * 100
        return (spot_cvd_change_5m * 1.5) + oi_change_5m


# --- TRADE MANAGER ---
class TradeManager:
    def __init__(self, mgr: BinanceManager, portfolio_risk_pct: float, reward_ratio: float, live_trading: bool):
        self.mgr = mgr
        self.PORTFOLIO_RISK_PCT = portfolio_risk_pct / 100.0 
        self.REWARD_RATIO = reward_ratio
        self.LIVE_TRADING = live_trading
        
        log_msg = f"TradeManager initialized: Risk={portfolio_risk_pct}%, R:R={reward_ratio}"
        if not self.LIVE_TRADING:
            log_msg += " -- [SIMULATION MODE ACTIVE. NO REAL TRADES WILL BE PLACED.] --"
            logging.warning(log_msg)
        else:
            log_msg += " -- [LIVE TRADING ACTIVE. REAL TRADES WILL BE PLACED.] --"
            logging.info(log_msg)


    async def get_atr(self, symbol: str) -> Optional[float]:
        try:
            kl_4h = await self.mgr.get_klines(symbol, '4h', 15, is_f=True) 
            if not kl_4h or len(kl_4h) < 15: return None
            df = pd.DataFrame(kl_4h, columns=['ts', 'o', 'h', 'l', 'c', 'v', 'ct', 'qv', 'tr', 'tbav', 'tbqv', 'ig'])
            df[['h', 'l', 'c']] = df[['h', 'l', 'c']].apply(pd.to_numeric)
            df['tr'] = np.maximum(df['h'] - df['l'], 
                                  np.maximum(abs(df['h'] - df['c'].shift()), 
                                             abs(df['l'] - df['c'].shift())))
            atr = df['tr'].rolling(window=14).mean().iloc[-1]
            return atr
        except Exception as e:
            logging.error(f"Failed to calculate ATR for {symbol}: {e}")
            return None

    async def execute_trade_entry(self, event_id: str, symbol: str):
        try:
            atr = await self.get_atr(symbol)
            all_tickers = await self.mgr.get_all_book_tickers()
            ticker = next((t for t in all_tickers if t['symbol'] == symbol), None)
            
            if not ticker:
                logging.warning(f"Skipping trade for {symbol}: Could not fetch ticker.")
                return
            if not atr:
                logging.warning(f"Skipping trade for {symbol}: Could not calculate ATR.")
                return

            entry_price = float(ticker['askPrice'])
            risk_per_coin = 2 * atr 
            stop_loss_price = round(entry_price - risk_per_coin, 4)
            reward_per_coin = risk_per_coin * self.REWARD_RATIO
            take_profit_price = round(entry_price + reward_per_coin, 4)

            account_balance = 10000.0 # Fictional balance
            risk_per_trade_usd = account_balance * self.PORTFOLIO_RISK_PCT
            position_size = round(risk_per_trade_usd / risk_per_coin, 3) 
            
            if not self.LIVE_TRADING:
                logging.info(f"--- [PAPER TRADE] ---")
                logging.info(f"Symbol: {symbol}")
                logging.info(f"Entry: {entry_price}, Size: {position_size}")
                logging.info(f"SL: {stop_loss_price}, TP: {take_profit_price}")
                logging.info(f"----------------------")
                
                actual_entry_price = entry_price
                tp_order_id = f"sim_tp_{int(time.time())}"
                sl_order_id = f"sim_sl_{int(time.time())}"

            else:
                entry_order = await self.mgr.place_market_order(symbol, 'BUY', position_size)
                if not entry_order or entry_order.get('status') != 'FILLED':
                    logging.error(f"Entry order failed for {symbol}: {entry_order}")
                    return
                
                actual_entry_price = float(entry_order['avgPrice'])
                logging.info(f"LIVE ENTRY FILLED: {position_size} {symbol} @ {actual_entry_price}")

                oco_orders = await self.mgr.place_oco_order(
                    symbol=symbol,
                    quantity=position_size,
                    take_profit_price=take_profit_price,
                    stop_loss_price=stop_loss_price
                )
                
                if not oco_orders:
                    logging.critical(f"OCO BRACKET FAILED for {symbol}. ATTEMPTING TO MARKET CLOSE.")
                    await self.mgr.place_market_order(symbol, 'SELL', position_size) 
                    return

                tp_order_id = oco_orders['tp_order']['orderId']
                sl_order_id = oco_orders['sl_order']['orderId']
            
            await DBManager.open_new_trade(
                event_id, symbol, actual_entry_price, 
                stop_loss_price, take_profit_price, position_size,
                tp_order_id, sl_order_id
            )
            await DBManager.update_status(event_id, 'PROCESSED')

        except Exception as e:
            logging.error(f"Error during trade execution for {symbol}: {e}", exc_info=True)

# --- MAIN APPLICATION ---
class MainApp:
    def __init__(self, config):
        self.config = config
        self.mgr = None
        self.engine = None
        self.trader = None
        self.live_trading = False 
    
    async def run(self):
        await DBManager.initialize()
        
        try:
            api_key = self.config.get('binance', 'api_key')
            api_secret = self.config.get('binance', 'api_secret')
            risk_pct = self.config.getfloat('settings', 'portfolio_risk_pct')
            rr_ratio = self.config.getfloat('settings', 'reward_ratio')
            self.live_trading = self.config.getboolean('settings', 'live_trading')
            
        except Exception as e:
            logging.error(f"FATAL: Could not read 'config.ini'. Make sure it exists and has all keys. Error: {e}")
            return

        async with aiohttp.ClientSession() as session:
            self.mgr = BinanceManager(session, api_key, api_secret)
            self.engine = StrategyEngine(self.mgr)
            self.trader = TradeManager(self.mgr, risk_pct, rr_ratio, self.live_trading)

            all_perps_info = await self.mgr.get_all_perp_info()
            all_symbols = [s['symbol'] for s in all_perps_info['symbols'] if s['quoteAsset'] == 'USDT']
            
            while True:
                try:
                    start_time = time.time()
                    
                    logging.info("--- Step 0: Curating Symbol Universe ---")
                    curated_symbols = await self.engine.run_universe_curation(all_symbols)
                    logging.info(f"Found {len(curated_symbols)} suitable symbols.")
                    
                    logging.info("--- Step 1 & 2: Running {REPLAY_WINDOW_HOURS}-Hour Replay Scan ---")
                    tasks = [self.engine.process_symbol_replay(s) for s in curated_symbols]
                    await asyncio.gather(*tasks)

                    logging.info("--- Step 3: Ranking Events & Checking Execution Status ---")
                    events = await DBManager.query_recent_events()
                    all_trades_from_db = await DBManager.get_live_trades()
                    live_trades_from_db = [t for t in all_trades_from_db if t['status'] == 'LIVE']
                    
                    # --- MODIFIED: Call new trigger function ---
                    await self._check_and_process_executable_signals(events, live_trades_from_db)
                    
                    if self.live_trading or (not self.live_trading and live_trades_from_db):
                         await self._monitor_live_trades(live_trades_from_db)
                    
                    results = await self._query_and_rank_events(events)
                    
                    self._display_results(results, curated_symbols, all_trades_from_db)
                    
                    elapsed = time.time() - start_time
                    wait_time = max(0, SCAN_INTERVAL_SECONDS - elapsed)
                    logging.info(f"Cycle finished in {elapsed:.2f}s. Waiting {wait_time:.2f}s.")
                    await asyncio.sleep(wait_time)
                
                except KeyboardInterrupt: 
                    break 
                except Exception as e:
                    logging.error(f"Main loop error: {e}", exc_info=True)
                    await asyncio.sleep(60)

    # ##################################################################
    # ## MODIFIED: This function now calls the new trigger ##
    # ##################################################################
    async def _check_and_process_executable_signals(self, events, live_trades_from_db):
        live_symbols = [t['symbol'] for t in live_trades_from_db]
        
        detected_events = [e for e in events if e['status'] == 'DETECTED']
        symbols_to_check = list(set([e['symbol'] for e in detected_events if e['symbol'] not in live_symbols]))

        if not symbols_to_check:
            return

        # --- MODIFIED: Call the new ignition trigger ---
        trigger_tasks = {s: self._check_ignition_trigger(s) for s in symbols_to_check}
        trigger_results = await asyncio.gather(*trigger_tasks.values())
        trigger_status_map = dict(zip(trigger_tasks.keys(), trigger_results))
        
        for event in detected_events:
            symbol = event['symbol']
            if symbol in live_symbols: 
                continue
            
            is_executable = trigger_status_map.get(symbol, False)
            if is_executable:
                logging.info(f"[TRADE] 🔥 IGNITION TRIGGER FIRED for {symbol}. Handing to TradeManager.")
                await DBManager.update_status(event['event_id'], 'EXECUTABLE')
                await self.trader.execute_trade_entry(event['event_id'], symbol)
                live_symbols.append(symbol) 

    async def _monitor_live_trades(self, live_trades):
        if not self.LIVE_TRADING:
            return 

        for trade in live_trades:
            try:
                tp_status = await self.mgr.check_order_status(trade['symbol'], trade['tp_order_id'])
                if tp_status and tp_status['status'] == 'FILLED':
                    logging.info(f"TAKE PROFIT HIT for {trade['symbol']}. Closing trade.")
                    await DBManager.close_trade(trade['trade_id'], 'TAKE_PROFIT')
                    logging.info(f"Cancelling SL order {trade['sl_order_id']} for {trade['symbol']}.")
                    await self.mgr.cancel_order(trade['symbol'], trade['sl_order_id'])
                    continue 

                sl_status = await self.mgr.check_order_status(trade['symbol'], trade['sl_order_id'])
                if sl_status and sl_status['status'] == 'FILLED':
                    logging.info(f"STOP LOSS HIT for {trade['symbol']}. Closing trade.")
                    await DBManager.close_trade(trade['trade_id'], 'STOP_LOSS')
                    logging.info(f"Cancelling TP order {trade['tp_order_id']} for {trade['symbol']}.")
                    await self.mgr.cancel_order(trade['symbol'], trade['tp_order_id'])
                    continue 

            except Exception as e:
                logging.error(f"Error monitoring trade {trade['trade_id']} ({trade['symbol']}): {e}")


    async def _query_and_rank_events(self, events: List) -> List[Dict]:
        now = datetime.now(timezone.utc)
        ranked_results = []
        for event in events:
            event_time = datetime.fromtimestamp(event['event_time'], tz=timezone.utc)
            age_minutes = (now - event_time).total_seconds() / 60
            decay_factor = 0.5 ** (age_minutes / RECENCY_HALF_LIFE_MIN)
            final_score = event['l2_score'] * decay_factor
            
            ranked_results.append({
                'final_score': final_score, 'symbol': event['symbol'], 'exchange': event['exchange'],
                'age_minutes': int(age_minutes), 'metrics': event['metrics'], 'status': event['status']
            })
        return sorted(ranked_results, key=lambda x: x['final_score'], reverse=True)

    # ##################################################################
    # ## NEW IGNITION TRIGGER FUNCTION (Replaces VWAP) ##
    # ##################################################################
    async def _check_ignition_trigger(self, symbol: str) -> bool:
        """
        Checks for the "Technical Synchronicity" trigger:
        1. Volume Surge
        2. Bollinger Band Expansion
        3. RSI > 50 (Momentum)
        4. ADX > 25 (Trend Strength)
        """
        try:
            # Fetch 100 15-minute candles to warm up indicators
            kl_15m = await self.mgr.get_klines(symbol, TRIGGER_TIMEFRAME, 100, is_f=True)
            if not kl_15m: 
                return False
            
            df = pd.DataFrame(kl_15m, columns=['ts', 'o', 'h', 'l', 'c', 'v', 'ct', 'qv', 'tr', 'tbav', 'tbqv', 'ig'])
            df[['c', 'v']] = df[['c', 'v']].apply(pd.to_numeric)
            
            # --- 1. Calculate Indicators ---
            # Use pandas-ta to calculate all indicators
            df.ta.bbands(length=20, std=2, append=True)   # Bollinger Bands (BBL_20_2.0, BBM_20_2.0, BBU_20_2.0, BBB_20_2.0)
            df.ta.rsi(length=14, append=True)             # RSI (RSI_14)
            df.ta.adx(length=14, append=True)             # ADX (ADX_14)
            df['vol_avg_20'] = df['v'].rolling(window=20).mean() # 20-period Volume MA
            
            # Drop NaN rows after calculations
            df.dropna(inplace=True)
            if df.empty:
                return False
                
            last_candle = df.iloc[-1]
            
            # --- 2. Check Trigger Conditions ---
            
            # Condition 1: Volume Surge
            volume_surge = last_candle['v'] > (last_candle['vol_avg_20'] * TRIGGER_VOL_MULT)
            
            # Condition 2: Bollinger Band Expansion
            # (Check if the current band width is greater than the previous one)
            bb_expansion = last_candle['BBB_20_2.0'] > df.iloc[-2]['BBB_20_2.0']
            
            # Condition 3: Momentum Confirmation (RSI)
            momentum_ok = last_candle['RSI_14'] > TRIGGER_RSI_MIN
            
            # Condition 4: Trend Confirmation (ADX)
            trend_ok = last_candle['ADX_14'] > TRIGGER_ADX_MIN
            
            # --- 3. Final Check ---
            is_triggered = volume_surge and bb_expansion and momentum_ok and trend_ok
            
            if is_triggered:
                logging.info(f"IGNITION CHECK: {symbol} PASSED. Vol: {volume_surge}, BB: {bb_expansion}, RSI: {momentum_ok}, ADX: {trend_ok}")
            
            return is_triggered

        except Exception as e:
            logging.debug(f"Error checking ignition trigger for {symbol}: {e}")
            return False
            
    # ##################################################################
    # ## UPDATED _display_results function ##
    # ##################################################################
    def _display_results(self, results: List[Dict], curated_symbols: List[str], all_trades: List):
        
        all_trades_map = {t['symbol']: t for t in all_trades}
        live_trade_symbols = [t['symbol'] for t in all_trades if t['status'] == 'LIVE']
        
        top_10_deduped = []
        seen_symbols = set()
        
        for res in results: 
            symbol = res['symbol']
            if symbol not in seen_symbols:
                top_10_deduped.append(res)
                seen_symbols.add(symbol)
            if len(top_10_deduped) >= 10:
                break 
        
        detected_symbols = []
        for r in top_10_deduped:
            if r['symbol'] not in live_trade_symbols:
                detected_symbols.append(r['symbol'])

        sim_tag = f" {Colors.YELLOW}(SIMULATION MODE){Colors.END}" if not self.live_trading else f" {Colors.GREEN}(LIVE TRADING){Colors.END}"
        summary_str = f"""
{Colors.BOLD}--- 🚀 4H Pump Bot Cycle Summary {sim_tag} ---{Colors.END}
🔭 {Colors.CYAN}Curated Universe:{Colors.END}   {len(curated_symbols)} Symbols
📊 {Colors.CYAN}Signals Found (6h):{Colors.END} {len(results)} Events (Unique: {len(seen_symbols)})
{Colors.GREEN}🟢 LIVE TRADES:{Colors.END}       ({len(live_trade_symbols)}) {', '.join(live_trade_symbols[:5]) + ('...' if len(live_trade_symbols) > 5 else '')}
{Colors.YELLOW}⏳ WAITING FOR TRIGGER:{Colors.END}  ({len(detected_symbols)}) {', '.join(detected_symbols[:5]) + ('...' if len(detected_symbols) > 5 else '')}
"""
        print(summary_str)

        headers = [
            f"{Colors.BOLD}🏆 Rank{Colors.END}",
            f"{Colors.BOLD}🪙 Symbol{Colors.END}",
            f"{Colors.BOLD}🔥 Score{Colors.END}",
            f"{Colors.BOLD}🕒 Age (min){Colors.END}",
            f"{Colors.BOLD}📊 Status{Colors.END}",
            f"{Colors.BOLD}📈 Trade Details{Colors.END}"
        ]
        
        table_data = []
        for i, res in enumerate(top_10_deduped):
            symbol = res['symbol']
            symbol_str = f"{Colors.CYAN}{symbol}{Colors.END}"
            trade_data = all_trades_map.get(symbol)
            
            if trade_data:
                entry = trade_data['entry_price']
                sl = trade_data['stop_loss_price']
                tp = trade_data['take_profit_price']
                
                details_str = f"{Colors.BOLD}Entry:{Colors.END} {entry}\n" \
                              f"{Colors.GREEN}TP:{Colors.END}    {tp}\n" \
                              f"{Colors.RED}SL:{Colors.END}    {sl}"
                
                if trade_data['status'] == 'LIVE':
                    status_str = f"{Colors.GREEN}LIVE 🟢{Colors.END}"
                elif trade_data['status'] == 'CLOSED':
                    status_str = f"{Colors.BLUE}CLOSED 🔵{Colors.END}"
                else: 
                    status_str = f"{Colors.GREEN}PROCESSED ✅{Colors.END}"
            
            else:
                details_str = str(res['metrics'])
                status_str = f"{Colors.YELLOW}DETECTED ⏳{Colors.END}"

            score = res['final_score']
            if score > 5000:
                score_str = f"{Colors.MAGENTA}{score:.0f}{Colors.END}"
            else:
                score_str = f"{score:.0f}"

            table_data.append([
                i + 1, 
                symbol_str, 
                score_str,
                f"{Colors.GREEN}{res['age_minutes']}{Colors.END}", 
                status_str, 
                details_str
            ])
        
        print(tabulate(table_data, headers=headers, tablefmt="grid"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Robust 4-Hour Pump Screener & Bot")
    args = parser.parse_args()
    
    config = configparser.ConfigParser()
    if not config.read('config.ini'):
        logging.error("FATAL: 'config.ini' file not found. Please create it.")
        sys.exit(1)

    import os
    os.makedirs('data', exist_ok=True)
    os.makedirs('logs', exist_ok=True)

    app = MainApp(config)
    try:
        asyncio.run(app.run())
    except KeyboardInterrupt:
        print(f"\n{Colors.BOLD}Application terminated.{Colors.END}")